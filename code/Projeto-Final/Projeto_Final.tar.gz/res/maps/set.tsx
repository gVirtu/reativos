<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tile" tilewidth="100" tileheight="100" tilecount="19" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="18">
  <image width="100" height="100" source="../Images/90_roofCorner.jpg"/>
 </tile>
 <tile id="19">
  <image width="100" height="100" source="../Images/90_roofEdge.jpg"/>
 </tile>
 <tile id="20">
  <image width="100" height="100" source="../Images/90_sidewalkCorner.jpg"/>
 </tile>
 <tile id="21">
  <image width="100" height="100" source="../Images/180_roofCorner.jpg"/>
 </tile>
 <tile id="22">
  <image width="100" height="100" source="../Images/180_roofEdge.jpg"/>
 </tile>
 <tile id="23">
  <image width="100" height="100" source="../Images/180_sidewalkCorner.jpg"/>
 </tile>
 <tile id="24">
  <image width="100" height="100" source="../Images/270_roofCorner.jpg"/>
 </tile>
 <tile id="25">
  <image width="100" height="100" source="../Images/270_roofEdge.jpg"/>
 </tile>
 <tile id="26">
  <image width="100" height="100" source="../Images/270_sidewalkCorner.jpg"/>
 </tile>
 <tile id="28">
  <image width="100" height="100" source="../Images/sidewalk_edge_down.jpg"/>
 </tile>
 <tile id="29">
  <image width="100" height="100" source="../Images/sidewalk_edge_left.jpg"/>
 </tile>
 <tile id="30">
  <image width="100" height="100" source="../Images/sidewalk_edge_right.jpg"/>
 </tile>
 <tile id="31">
  <image width="100" height="100" source="../Images/sidewalk_edge_up.jpg"/>
 </tile>
 <tile id="33">
  <image width="100" height="100" source="../Images/asphalt.jpg"/>
 </tile>
 <tile id="35">
  <image width="100" height="100" source="../Images/roof_edge_up.jpg"/>
 </tile>
 <tile id="36">
  <image width="100" height="100" source="../Images/0_roofCorner.jpg"/>
 </tile>
 <tile id="37">
  <image width="100" height="100" source="../Images/0_roofEdge.jpg"/>
 </tile>
 <tile id="38">
  <image width="100" height="100" source="../Images/0_sidewalkCorner.jpg"/>
 </tile>
 <tile id="39">
  <image width="100" height="100" source="../Images/crates.jpg"/>
 </tile>
</tileset>
