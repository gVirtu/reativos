# Gravity Runner

#### Sobre o jogo

Gravity Runner é um jogo de plataforma no qual o personagem deve alterar a gravidade de de forma a evitar cair das plataformas e alacançar a maior distância possível. Além disso existem itens bônus que podem ser coletados alterando a gravidade para alcançá-los e automaticamente o jogador é devolvido à plataforma inicial.

#### Modos de Jogo

O Gravity Runner possui 3 modos de jogo:
   - Padrão: O modo no qual o jogo é iniciado;
   - Hard: Modo difícil com plataformas menores, em maior número, e sendo ultrapassadas com maior velocidade. Esse modo pode ser ativado durante o jogo;
   - Auto: Modo automático jogado pelo computador. Ele pode ser ativado durante o jogo, tanto no modo Padrão como no modo Hard;
 
#### Controles

 - Seta para cima: muda a gravidade para cima;
 - Seta para baixo: muda a gravidade para baixo;
 - Espaço: muda a gravidade tanto para cima quanto para baixo;
 - A-U-T-O: Ao digitar (durante o jogo) a palavra "auto" o jogo entra no modo automático
 - H-A-R-D: Ao digitar durante o jogo a palavra "hard" o jogo entra no modo Hard
 - P: Pausa o jogo
